import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppComponent} from './app/app.component';
import {SizePipe} from './pipes/size.pipe';
import {TaskComponent} from './task/task.component';
import {TimePipe} from './pipes/time.pipe';
import {TaskListComponent} from './task-list/task-list.component';
import {SettingsComponent} from './settings/settings.component';

@NgModule({
  declarations: [
    AppComponent,
    TaskComponent,
    SizePipe,
    TimePipe,
    TaskListComponent,
    SettingsComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
