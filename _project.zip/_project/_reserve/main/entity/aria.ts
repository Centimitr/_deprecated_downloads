const require = window['require'];
const {app} = window['require']('electron').remote;
const _path = require('path');
const {spawn, execSync} = require('child_process');
import {options} from "./options";

const DEVELOPING = true;
const ARIA_FILENAME = 'usertaskd';
let ariaPath = _path.join(app.getAppPath(), 'app.asar.unpacked', ARIA_FILENAME);
if (DEVELOPING) {
  ariaPath = `/Users/shixiao/Playground/downloads/${ARIA_FILENAME}`
}
const DEFAULT_PORT = 6800;
console.log(ariaPath);

const Aria2 = window['Aria2'];
const a = new Aria2({'host': 'localhost', 'port': 6800, });

class Deamon {

  constructor(public path) {
  }

  _onStart: Function[] = [];
  handler: any;
  ready = false;
  terminating = false;
  port = DEFAULT_PORT;

  async init() {
    console.log('INIT!');
    this.start();
    app.on('quit', () => {
      this.kill()
    })
  }

  start() {
    try {
      execSync(`killall -9 ${ARIA_FILENAME}`);
    } catch (e) {

    }
    console.log('KILLED!');

    this.handler = spawn(this.path, options.concat([`--rpc-listen-port=${this.port}`]));
    this._onStart.forEach(cb => cb(this.port));
    console.log(this.handler);

    this.handler.stdout.on('data', (data) => {
      console.log(`stdout: ${data}`)
    });
    this.handler.stderr.on('data', (data) => {
      console.log(`stderr: ${data}`)
    });
    this.handler.on('close', (code) => {
      console.log(`child process exited with code ${code}`);
      if (!this.terminating) {
        console.log('restart...');
        this.port++;
        this.start()
      }
    })
  }

  kill() {
    if (this.handler && this.handler.kill) {
      this.terminating = true;
      return this.handler.kill()
    }
  }

  onStart(callback: Function) {
    this._onStart.push(callback)
  }
}

const ad = new Deamon(ariaPath);

export {
  a,
  ad
}
