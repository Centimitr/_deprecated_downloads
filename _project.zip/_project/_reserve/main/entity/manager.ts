import {a} from "./aria";
import {Task} from "./task";

export class Manager {
  m = new Map();

  constructor() {
    window['m'] = this;
  }

  SESSION_SAVE_INTERVAL = 60 * 1000 * 1000;
  ready = false;

  initAriaCallbacks() {
    ['onDownloadStart', 'onDownloadPause', 'onDownloadStop', 'onDownloadComplete', 'onDownloadError', 'onBtDownloadComplete'].forEach(name => {
      a[name] = async data => {
        const t = this.m.get(data.gid);
        if (t) {
          await t.update();
          this.scheduleSaveSession();
        }
      };
    });
  }

  async init() {
    this.readSession();
    const options = {};
    this.initAriaCallbacks();
    await a.changeGlobalOption(options);
    await a.open();
    setInterval(() => this.scheduleSaveSession(), this.SESSION_SAVE_INTERVAL);
    this.ready = true;
  }

  SESSION_KEY = 'KITSUNE_DOWNLOADS_SESSION';

  readSession() {
    const str = window.localStorage.getItem(this.SESSION_KEY);
    if (str) {
      const objs = JSON.parse(str);
      console.log('READ SESSION:', objs);
      objs.map(obj => Task.from(obj)).forEach(t => this.m.set(t.gid, t));
    }
  }

  saveSession() {
    console.log('SAVE SESSION:', Array.from(this.m.entries()).map(arr => arr[1]));
    window.localStorage.setItem(this.SESSION_KEY, JSON.stringify(Array.from(this.m.entries()).map(arr => arr[1])))
  }

  SESSION_SAVE_MIN_INTERVAL = 6 * 1000 * 1000;
  lastSaveSessionTime = 0;

  scheduleSaveSession() {
    const t = Date.now();
    let ok = false;
    if (t - this.lastSaveSessionTime > this.SESSION_SAVE_MIN_INTERVAL) {
      this.saveSession();
      ok = true;
    }
    this.lastSaveSessionTime = t;
    return ok;
  }

  async add(uris) {
    const gid = await a.addUri(uris);
    this.m.set(gid, new Task(gid, uris));
  }

  async pauseAll() {
    return await a.pauseAll();
  }

  async unpauseAll() {
    return await a.unpauseAll();
  }

  getByStatus(types) {
    return Array.from(this.m.values())
      .filter(t => t.status)
      .filter(t => types.includes(t.status.status));
  }

  getByDate(tasks, timeFn) {
    const l = [];
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDay());
    const DAY = 1000 * 60 * 60 * 24;
    const PAST = now.getTime() - today.getTime();
    const recent = n => PAST + (n - 1) * DAY;
    const ranges: any[] = [{t: 'today', v: PAST}, {t: 'yesterday', v: recent(2)}, {
      t: 'recent 7 days',
      v: recent(7)
    }, {t: 'recent 15 days', v: recent(15)}, {t: 'recent 30 days', v: recent(30)}, {t: '30 days before', v: Infinity}];
    tasks.forEach(t => {
      const diff = now.getTime() - timeFn(t);
      const r = ranges.find(r => diff < r.v);
      // console.log(r, diff, t, timeFn(t))
      r.s = r.s || [];
      r.s.push(t);
    });
    return ranges.filter(r => r.s && r.s.length);
  }

  getPresent() {
    return this.getByStatus(['waiting', 'active', 'paused', 'error'])
  }

  getPast() {
    return this.getByStatus(['removed', 'complete']);
  }

  getPresentByDate() {
    return this.getByDate(this.getPresent(), t => t.createTime);
  }

  getPastByDate() {
    return this.getByDate(this.getPast(), t => t.completeTime);
  }

  getDownloadSpeed() {
    return this.getPresent().map(t => t.status).filter(s => s).map(s => s.downloadSpeed).concat([0]).reduce((a, b) => +a + +b);
  }


  refresher: any;
  refreshFreq = 1000;

  startAutoRefresh() {
    this.refresher = setInterval(() => this.getPresent().forEach(t => t.update()), this.refreshFreq)
  }

  stopAutoRefresh() {
    clearInterval(this.refresher)
  }

  async printOption() {
    const o = await a.getGlobalOption();
    console.log(o);
  }
}
