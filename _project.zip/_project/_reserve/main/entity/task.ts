const {shell, dialog, clipboard, remote} = window['require']('electron');
import {a} from "./aria";

export class Task {
  createTime = 0;
  completeTime = 0;
  status: any;

  constructor(public gid, public uris) {
    this.createTime = Date.now();
    (async () => this.update())();
  }

  static from(obj) {
    const t = new Task(obj.gid, obj.uris);
    Object.assign(t, obj);
    return t;
  }

  async update() {
    const status = await a.tellStatus(this.gid);
    if (status.status === 'complete' && this.status.status !== 'complete') {
      this.completeTime = Date.now();
    }
    this.status = status;
  }

  async pause() {
    return await a.pause(this.gid);
  }

  async unpause() {
    return await a.unpause(this.gid);
  }

  async remove() {
    return await a.remove(this.gid);
  }

  isActive() {
    return this.status && this.status.status === 'active'
  }

  isPaused() {
    return this.status && this.status.status === 'paused'
  }

  isComplete() {
    return this.status && this.status.status === 'complete'
  }

  getName() {
    if (this.status && this.status.files) {
      const files = this.status.files;
      const selected = files.filter(f => f.selected);
      return (selected[0] || files[0]).path.split('/').pop() || '?'
    }
    return 'fetching...'
  }

  getNameExt() {
    const ext = this.getName().split('.').pop() || '?';
    return ext.length > 3 ? '?' : ext
  }

  getCompleteRate() {
    const s = this.status;
    if (s) {
      const v = (s.completedLength / s.totalLength * 100).toFixed(1);
      return (isNaN(+v) ? '0' : v) + '%';
    }
  }

  getEstimateTime() {
    const s = this.status;
    if (s) {
      const speed = s.downloadSpeed;
      const rest = s.totalLength - s.completedLength;
      return rest / speed;
    }
  }

  getCopyLinks() {
    return this.uris.join('\n\r')
  }

  open(forceFolder) {
    const s = this.status;
    if (s) {
      const path = s.files.length > 1 ? s.dir : s.files[0].path;
      const ok = forceFolder ? shell.showItemInFolder(path) : shell.openItem(path);
      if (!ok) {
        console.log('DBCLICK: Ok?:', ok, path)
      }
    }
  }

  openDestination() {
    return this.open(true)
  }
}
