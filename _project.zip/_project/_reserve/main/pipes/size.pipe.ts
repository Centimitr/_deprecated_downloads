import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'size'
})
export class SizePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    value = parseInt(value);
    const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB'];
    let i = 0;
    for (; i < units.length; i++, value = value / 1024) {
      if (value <= 1024) {
        break
      }
    }
    value = value.toFixed(2);
    if (value - 0 < 0.01) {
      value = 0
    }
    return `${value} ${units[i]}`;
  }
}
