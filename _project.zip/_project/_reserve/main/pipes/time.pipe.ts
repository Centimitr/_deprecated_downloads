import {Pipe, PipeTransform} from '@angular/core';

const fix = function (v) {
  const num = +v.toFixed(0);
  return `${num < 10 ? '0' : ''}${num}`;
};

const nan = function (v) {
  return isNaN(+v) ? '--' : v;
};

@Pipe({
  name: 'time'
})
export class TimePipe implements PipeTransform {

  transform(v: any, args?: any): any {
    if (v === Infinity) {
      return 'Infinity';
    }
    v = v.toFixed(0);
    const second = fix(v % 60);
    const hour = fix(v / 3600);
    const minute = fix((v - 3600 * +(hour) - +(second)) / 60);
    return `${nan(hour)}:${nan(minute)}:${nan(second)}`;
  }

}
