import {Component, HostListener, Input, OnInit} from '@angular/core';

const {remote, clipboard} = window['require']('electron');
const {Menu, MenuItem} = remote;
const DBLCLICK_THRESHOLD = 200;

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent {

  @Input() list: any[];
  selected: any[] = [];

  @HostListener('mousedown')
  cancelSelection() {
    this.selected = [];
  }

  lastToggleGid: any;
  lastToggleTime = 0;

  toggle(e, t) {
    e.cancelBubble = true;
    const now = Date.now();
    const gid = t.gid;
    let dblclick = false;
    if (gid === this.lastToggleGid && now - this.lastToggleTime < DBLCLICK_THRESHOLD) {
      dblclick = true;
    }
    this.lastToggleGid = gid;
    this.lastToggleTime = now;

    const meta = e.metaKey;
    const exist = this.selected.includes(gid);
    if (e.which === 1) {
      if (!exist) {
        if (!meta) {
          this.selected = [gid];
        } else {
          this.selected.push(gid);
        }
      } else {
        if (meta) {
          this.selected = this.selected.filter(g => g !== gid)
        } else {
          this.selected = [gid];
          if (dblclick) {
            console.log('DBLCLICK!');
            if (t.isActive()) {
              t.pause();
            } else if (t.isPaused()) {
              t.unpause();
            } else if (t.isComplete()) {
              t.open();
            }
          }
        }
      }
    } else if (e.which === 3) {
      if (!exist) {
        this.selected = [gid];
      }
      setTimeout(() => {
        this.popupMenu(e.x, e.y, t)
      }, 15);
    }
  }

  popupMenu(x, y, t) {
    const menu = new Menu();
    if (this.selected.length > 1) {
      menu.append(new MenuItem({label: `Selected: ${this.selected.length} items`}));
      menu.append(new MenuItem({type: 'separator'}));
    }
    menu.append(new MenuItem({
      label: 'Start', click() {
        t.unpause()
      }, enabled: t.isPaused()
    }));
    menu.append(new MenuItem({
      label: 'Pause', click() {
        t.pause()
      }, enabled: t.isActive()
    }));
    menu.append(new MenuItem({
      label: 'Remove', click() {
        t.unpause()
      }
    }));
    menu.append(new MenuItem({type: 'separator'}));
    menu.append(new MenuItem({
      label: 'Copy Link', click() {
        clipboard.writeText(t.getCopyLinks())
      }
    }));
    menu.append(new MenuItem({type: 'separator'}));
    menu.append(new MenuItem({
      label: 'Open...', click() {
        t.open()
      }, enabled: t.isComplete()
    }));
    menu.append(new MenuItem({
      label: 'Open Destination...', click() {
        t.openDestination()
      }
    }));

    menu.popup(remote.getCurrentWindow(), {y, x, async: true})
  }
}
