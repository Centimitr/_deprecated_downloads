import {Component, HostListener, NgZone} from '@angular/core';

const {remote, ipcRenderer} = window['require']('electron');

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private _ngZone: NgZone) {
  }

  uri: string;
  destination: string = '/Users/shixiao/Downloads/';

  close() {
    window.close()
  }

  @HostListener('document:keyup', ['$event'])
  onKeyUp(e) {
    switch (e.key) {
      case 'Escape':
        this.close();
        break;
      case 'Enter':
        this.add()
    }
  }

  add() {
    const w = remote.getCurrentWindow();
    if (this.uri) {
      const uris = [];
      uris.push(this.uri);
      const ok = w.getParentWindow().webContents.executeJavaScript(`window.m.add(${JSON.stringify(uris)})`);
      console.log(ok);
      this.close()
    } else {
      console.warn('missing values!')
    }
  }

  async changeDir() {
    const d = remote.dialog;
    const path = await d.showOpenDialog({
      properties: ['openDirectory', 'createDirectory'],
    });
    if (path && path[0]) {
      this.destination = path.pop()
    }
  }
}
