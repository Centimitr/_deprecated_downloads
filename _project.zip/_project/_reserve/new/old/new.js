window.detectEsc = function (e) {
  if (e.key === 'Escape') {
    window.close()
  }
}
window.add = function () {
  const w = require('electron').remote.getCurrentWindow()
  const v = document.querySelector('#uris').value
  if (v) {
    const uris = []
    uris.push(v)
    const ok = w.getParentWindow().
      webContents.
      executeJavaScript(`window.m.add(${JSON.stringify(uris)})`)
    console.log(ok)
    window.close()
  } else {
    console.warn('missing values!')
  }
}
window.changeDir = async function () {
  const dir = document.querySelector('#dir')
  const d = require('electron').remote.dialog
  const path = await d.showOpenDialog({
    properties: ['openDirectory', 'createDirectory'],
  })
  dir.innerText = path.pop()
}