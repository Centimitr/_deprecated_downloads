import {Component, NgZone} from '@angular/core';
import {Manager} from "../entity/manager";

const {remote, ipcRenderer} = window['require']('electron');

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  panel = 0;
  panels = ['running', 'completed', 'settings'];
  m =  new Manager();
  active: boolean;

  constructor(private _ngZone: NgZone) {
    // const tray = new Tray();
    // tray.setTitle('Downloads');
    window['x'] = (fn) => {
      this._ngZone.run(() => fn())
    };
    const w = remote.getCurrentWindow();
    this.active = w.isFocused();
    w.on('blur', () => this._ngZone.run(() => this.active = false));
    w.on('focus', () => this._ngZone.run(() => this.active = true));

    (async () => {
      await this.m.init();
      this.m.startAutoRefresh();
    })();
    this.switchPanel(0);
  }

  switchPanel(index) {
    if (index === this.panel) {
      return;
    }
    this.panel = index;
  }

  async openDownloadPanel() {
    await ipcRenderer.send('kitsune', 'openDownloadPanel')
  }

}
