const require = window['require'];
const {app} = window['require']('electron').remote;
const _path = require('path');
const {spawn, execSync} = require('child_process');

const DEVELOPING = true;
const ARIA_FILENAME = 'usertaskd';
let ariaPath = _path.join(app.getAppPath(), 'app.asar.unpacked', ARIA_FILENAME);
if (DEVELOPING) {
  ariaPath = `/Users/shixiao/Playground/downloads/${ARIA_FILENAME}`
}
const DEFAULT_PORT = 6800;
console.log(ariaPath);

const Aria2 = window['Aria2'];
const a = new Aria2({'host': 'localhost', 'port': 6800,});

class Provider {
}

export {
  a,
}
